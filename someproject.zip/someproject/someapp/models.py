from django.db import models
from django.urls import reverse

class Event(models.Model):
    CATEGORY_CHOICES = [
        ('concerts', 'Концерты'),
        ('exhibitions', 'Выставки'),
        ('theater', 'Театр'),
        ('sports', 'Спорт'),
        ('workshops', 'Мастер-классы'),
    ]
    
    title = models.CharField('Название', max_length=200)
    description = models.TextField('Описание')
    date = models.DateField('Дата')
    location = models.CharField('Место проведения', max_length=300)
    address = models.CharField('Адрес', max_length=300)
    category = models.CharField('Категория', max_length=20, choices=CATEGORY_CHOICES)
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField('Создано', auto_now_add=True)
    
    class Meta:
        verbose_name = 'Мероприятие'
        verbose_name_plural = 'Мероприятия'
        ordering = ['date']
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('event_detail', kwargs={'event_id': self.id})