from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.db import models
from .models import Event

def event_list(request):
    """Главная страница со списком мероприятий"""
    events = Event.objects.all().order_by('date')
    
    # Для AJAX запроса (фильтрация)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        category = request.GET.get('category', 'all')
        search = request.GET.get('search', '')
        
        if category != 'all':
            events = events.filter(category=category)
        
        if search:
            events = events.filter(
                models.Q(title__icontains=search) |
                models.Q(description__icontains=search) |
                models.Q(location__icontains=search) |
                models.Q(address__icontains=search)
            )
        
        events_data = []
        for event in events:
            events_data.append({
                'id': event.id,
                'title': event.title,
                'description': event.description,
                'date': event.date.strftime('%d'),
                'month': event.date.strftime('%B').lower(),
                'category': event.category,
                'location': f"{event.location}, {event.address}",
                'price': str(event.price),
            })
        
        return JsonResponse({'events': events_data})
    
    return render(request, 'index.html', {'events': events})

def event_detail(request, event_id):
    """Детальная страница мероприятия"""
    event = get_object_or_404(Event, id=event_id)
    return render(request, 'event_detail.html', {'event': event})